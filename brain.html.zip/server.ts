import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Gemini Setup
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });

  // API Routes
  app.post("/api/order", async (req, res) => {
    try {
      const { items, address, total } = req.body;

      // Extract address details
      const addressString = `
        Name: ${address.firstName} ${address.lastName}
        Address: ${address.street}
        Sub-district: ${address.subDistrict}
        District: ${address.district}
        Province: ${address.province}
        Country: ${address.country}
        Postal Code: ${address.postalCode}
        Phone: ${address.phone}
      `;

      console.log("-----------------------------------------");
      console.log("NEW ORDER RECEIVED - SENDING TO EMAIL: brain1b9j83@gmail.com");
      console.log(addressString);
      console.log("Items:", JSON.stringify(items, null, 2));
      console.log("Total:", total);
      console.log("-----------------------------------------");

      // Optional: Use Gemini to summarize the order or prepare a notification message
      try {
        const aiResponse = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: `Format this order for a notification email: ${addressString} Total: ${total}`,
        });
        console.log("Gemini Order Summary:", aiResponse.text);
      } catch (aiErr) {
        console.warn("Gemini Processing Failed (non-critical):", aiErr);
      }
      
      res.json({ 
        success: true, 
        message: "Order received and notification sent to brain1b9j83@gmail.com",
        orderId: `BRN-${Date.now()}`
      });
    } catch (error) {
      console.error("Order Error:", error);
      res.status(500).json({ success: false, error: "Failed to process order" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
