import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, X, ChevronRight, CheckCircle2, MapPin, Phone, User, Globe, ArrowLeft, Loader2 } from 'lucide-react';
import { useCartStore } from './store/useCartStore';
import { PRODUCTS } from './data';
import { Address, Product } from './types';

type View = 'HOME' | 'CHECKOUT' | 'SUCCESS';

export default function App() {
  const [view, setView] = useState<View>('HOME');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const { items, addItem, removeItem, updateQuantity, getTotal, clearCart } = useCartStore();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderDetails, setOrderDetails] = useState<any>(null);

  // Address form state
  const [address, setAddress] = useState<Address>({
    firstName: '',
    lastName: '',
    street: '',
    subDistrict: '',
    district: '',
    province: '',
    country: 'Thailand',
    postalCode: '',
    phone: ''
  });

  const handleAddToCart = (product: Product) => {
    addItem(product, 'L'); // Default size for demo
    setIsCartOpen(true);
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items,
          address,
          total: getTotal()
        })
      });

      const result = await response.json();
      if (result.success) {
        setOrderDetails({ ...result, address, items, total: getTotal() });
        setView('SUCCESS');
        clearCart();
      }
    } catch (error) {
      console.error('Order failed:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-editorial-bg text-editorial-text font-sans selection:bg-black selection:text-white">
      {/* Navbar */}
      <nav className="fixed top-0 w-full z-40 bg-white/80 backdrop-blur-md border-b border-editorial-border">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <button 
            onClick={() => setView('HOME')}
            className="font-serif text-3xl font-black tracking-tighter italic uppercase"
          >
            BRAIN
          </button>
          
          <div className="flex items-center gap-8">
            <button className="hidden md:block uppercase text-[11px] font-bold tracking-widest opacity-60 hover:opacity-100 transition-opacity">Collection</button>
            <button className="hidden md:block uppercase text-[11px] font-bold tracking-widest opacity-60 hover:opacity-100 transition-opacity">Archive</button>
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 hover:bg-black/5 rounded-full transition-colors"
            >
              <ShoppingBag size={24} />
              {items.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-black text-white text-[10px] w-5 h-5 flex items-center justify-center rounded-full font-bold">
                  {items.reduce((acc, item) => acc + item.quantity, 0)}
                </span>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-20">
        <AnimatePresence mode="wait">
          {view === 'HOME' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-7xl mx-auto px-6 py-12"
            >
              {/* Hero */}
              <div className="relative h-[65vh] md:h-[80vh] w-full border border-editorial-border bg-white p-4 mb-20">
                <div className="w-full h-full overflow-hidden relative">
                  <img 
                    src="https://images.unsplash.com/photo-1558769132-cb1aea458c5e?q=80&w=2000&auto=format&fit=crop" 
                    alt="Hero"
                    className="w-full h-full object-cover grayscale opacity-90 transition-transform duration-1000 hover:scale-105"
                  />
                  <div className="absolute inset-x-8 bottom-12 flex flex-col items-start text-left text-white drop-shadow-2xl">
                    <motion.h1 
                      initial={{ y: 20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      transition={{ delay: 0.2 }}
                      className="font-serif text-6xl md:text-[10rem] font-bold leading-[0.85] tracking-tighter italic mb-4"
                    >
                      THE CORE
                    </motion.h1>
                    <p className="max-w-md text-lg md:text-xl font-medium tracking-tight bg-black px-4 py-1 italic">
                      Conceptual Apparel for Mindful Rebels.
                    </p>
                  </div>
                </div>
              </div>

              {/* Product Grid */}
              <section id="products">
                <div className="flex items-end justify-between mb-16 border-b border-editorial-border pb-8">
                  <div className="text-left">
                    <p className="text-[10px] uppercase tracking-[0.3em] font-black opacity-30 mb-2 italic">Volume 01: Origins</p>
                    <h2 className="font-serif text-5xl font-bold uppercase tracking-tight italic">Collection 24/25</h2>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
                  {PRODUCTS.map((product) => (
                    <motion.div 
                      key={product.id}
                      whileHover={{ y: -8 }}
                      className="group cursor-pointer"
                      onClick={() => handleAddToCart(product)}
                    >
                      <div className="aspect-[3/4] bg-white border border-editorial-border p-3 overflow-hidden mb-6 relative transition-shadow hover:shadow-xl">
                        <img 
                          src={product.image} 
                          alt={product.name}
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale"
                        />
                        <div className="absolute top-6 left-6 text-[9px] font-bold opacity-0 group-hover:opacity-40 italic tracking-widest transition-opacity uppercase">BRAIN ARCHIVE NO. {product.id}</div>
                      </div>
                      <div className="text-center">
                        <h3 className="font-serif italic text-2xl mb-1">{product.name}</h3>
                        <p className="text-[11px] opacity-40 font-bold uppercase tracking-widest mb-3">{product.category}</p>
                        <p className="font-medium text-lg italic tracking-tight opacity-70">฿{product.price.toLocaleString()}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </section>
            </motion.div>
          )}

          {view === 'CHECKOUT' && (
            <motion.div
              key="checkout"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-6xl mx-auto px-6 py-12"
            >
              <button 
                onClick={() => setView('HOME')}
                className="flex items-center gap-2 text-black/40 hover:text-black mb-12 transition-colors uppercase text-[10px] font-black tracking-widest italic"
              >
                <ArrowLeft size={16} />
                Back to Collection
              </button>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 text-left">
                {/* Checkout Form */}
                <section>
                  <div className="mb-12">
                    <p className="text-[10px] uppercase tracking-[0.3em] font-black opacity-30 mb-2 italic">Step 02 / 03</p>
                    <h2 className="font-serif text-5xl font-bold italic">Shipping Details</h2>
                  </div>

                  <form onSubmit={handleSubmitOrder} className="space-y-10">
                    <div className="grid grid-cols-2 gap-10">
                      <div className="space-y-3">
                        <label className="text-[10px] uppercase font-black tracking-widest text-black opacity-30">First Name</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-transparent border-b border-editorial-border py-4 focus:border-black outline-none transition-all font-medium"
                          placeholder="John"
                          value={address.firstName}
                          onChange={(e) => setAddress({...address, firstName: e.target.value})}
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] uppercase font-black tracking-widest text-black opacity-30">Last Name</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-transparent border-b border-editorial-border py-4 focus:border-black outline-none transition-all font-medium"
                          placeholder="Doe"
                          value={address.lastName}
                          onChange={(e) => setAddress({...address, lastName: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="text-[10px] uppercase font-black tracking-widest text-black opacity-30">Street Address</label>
                      <input 
                        required
                        type="text" 
                        className="w-full bg-transparent border-b border-editorial-border py-4 focus:border-black outline-none transition-all font-medium"
                        placeholder="123 Sukhumvit Road"
                        value={address.street}
                        onChange={(e) => setAddress({...address, street: e.target.value})}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-10">
                      <div className="space-y-3">
                        <label className="text-[10px] uppercase font-black tracking-widest text-black opacity-30">Sub-district</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-transparent border-b border-editorial-border py-4 focus:border-black outline-none transition-all font-medium"
                          placeholder="Khlong Toei"
                          value={address.subDistrict}
                          onChange={(e) => setAddress({...address, subDistrict: e.target.value})}
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] uppercase font-black tracking-widest text-black opacity-30">District</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-transparent border-b border-editorial-border py-4 focus:border-black outline-none transition-all font-medium"
                          placeholder="Watthana"
                          value={address.district}
                          onChange={(e) => setAddress({...address, district: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-10">
                      <div className="space-y-3">
                        <label className="text-[10px] uppercase font-black tracking-widest text-black opacity-30">Province</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-transparent border-b border-editorial-border py-4 focus:border-black outline-none transition-all font-medium"
                          placeholder="Bangkok"
                          value={address.province}
                          onChange={(e) => setAddress({...address, province: e.target.value})}
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] uppercase font-black tracking-widest text-black opacity-30">Country</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-transparent border-b border-editorial-border py-4 focus:border-black outline-none transition-all font-medium"
                          placeholder="Thailand"
                          value={address.country}
                          onChange={(e) => setAddress({...address, country: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-10">
                      <div className="space-y-3">
                        <label className="text-[10px] uppercase font-black tracking-widest text-black opacity-30">Postal Code</label>
                        <input 
                          required
                          type="text" 
                          className="w-full bg-transparent border-b border-editorial-border py-4 focus:border-black outline-none transition-all font-medium"
                          placeholder="10110"
                          value={address.postalCode}
                          onChange={(e) => setAddress({...address, postalCode: e.target.value})}
                        />
                      </div>
                      <div className="space-y-3">
                        <label className="text-[10px] uppercase font-black tracking-widest text-black opacity-30">Phone</label>
                        <input 
                          required
                          type="tel" 
                          className="w-full bg-transparent border-b border-editorial-border py-4 focus:border-black outline-none transition-all font-medium"
                          placeholder="081 234 5678"
                          value={address.phone}
                          onChange={(e) => setAddress({...address, phone: e.target.value})}
                        />
                      </div>
                    </div>

                    <button 
                      disabled={isSubmitting}
                      className="w-full bg-black text-white py-6 font-serif italic text-2xl hover:bg-[#333] transition-colors flex items-center justify-center gap-4 disabled:opacity-70"
                    >
                      {isSubmitting ? <Loader2 className="animate-spin" /> : 'Confirm Order & Send Details'}
                    </button>
                    <p className="text-center text-[10px] font-bold tracking-[0.2em] opacity-30 uppercase">
                      Confirming will notify brain1b9j83@gmail.com
                    </p>
                  </form>
                </section>

                {/* Summary */}
                <section className="bg-white border border-editorial-border p-10 h-fit">
                  <h3 className="font-serif italic text-3xl mb-10 border-b border-editorial-border pb-6">Your Archive</h3>
                  <div className="space-y-8 mb-12">
                    {items.map((item) => (
                      <div key={`${item.id}-${item.size}`} className="flex gap-6">
                        <div className="w-20 h-24 bg-gray-50 border border-editorial-border p-1 shrink-0">
                          <img src={item.image} className="w-full h-full object-cover grayscale" alt={item.name} />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between font-serif italic text-xl">
                            <span>{item.name}</span>
                            <span>฿{(item.price * item.quantity).toLocaleString()}</span>
                          </div>
                          <p className="text-[10px] font-black uppercase tracking-widest opacity-30 mt-2">Qty: {item.quantity} / Sz: {item.size}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="space-y-4 pt-8 border-t border-editorial-border font-medium">
                    <div className="flex justify-between items-end">
                      <span className="text-[10px] uppercase font-black tracking-widest opacity-30 italic">Subtotal</span>
                      <span className="font-display italic">฿{getTotal().toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between items-end">
                      <span className="text-[10px] uppercase font-black tracking-widest opacity-30 italic">Priority Shipping</span>
                      <span className="text-green-600 text-xs italic font-bold">INCLUDED</span>
                    </div>
                    <div className="flex justify-between items-end pt-6">
                      <span className="font-serif italic text-2xl">Total Value</span>
                      <span className="font-serif italic text-4xl">฿{getTotal().toLocaleString()}</span>
                    </div>
                  </div>
                </section>
              </div>
            </motion.div>
          )}

          {view === 'SUCCESS' && (
            <motion.div
              key="success"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="max-w-xl mx-auto px-6 py-20 text-center"
            >
              <div className="mb-12">
                <p className="text-[11px] font-black tracking-[0.4em] uppercase opacity-30 mb-8 italic">Order Complete</p>
                <div className="w-24 h-24 border border-black rounded-full flex items-center justify-center mx-auto mb-10">
                  <CheckCircle2 size={40} strokeWidth={1} />
                </div>
                <h2 className="font-serif text-7xl font-bold italic mb-6">Confirmed.</h2>
                <p className="text-black/50 text-lg leading-relaxed max-w-sm mx-auto">
                  Archives reserved. A detailed summary has been dispatched to 
                  <span className="block text-black font-serif italic mt-2">brain1b9j83@gmail.com</span>
                </p>
              </div>

              <div className="bg-white border border-editorial-border p-12 mb-16 shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] text-left relative overflow-hidden">
                <div className="relative z-10">
                  <p className="font-black uppercase tracking-[0.3em] text-[10px] mb-8 opacity-40">Scan to Finalize Archives</p>
                  <div className="flex gap-10 items-center">
                    <div className="w-32 h-32 bg-white border border-black p-1 shrink-0">
                      <img 
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=PROMPTPAY_${orderDetails?.total}`} 
                        alt="Payment"
                        className="w-full h-full"
                      />
                    </div>
                    <div>
                      <h4 className="font-serif italic text-2xl mb-1">฿{orderDetails?.total.toLocaleString()}</h4>
                      <p className="text-[9px] font-bold uppercase tracking-widest opacity-30 leading-relaxed max-w-[150px]">
                        Scan with any mobile banking app to process Priority Settlement.
                      </p>
                    </div>
                  </div>
                </div>
                <div className="absolute top-0 right-0 p-8 font-serif italic opacity-[0.03] text-9xl">BRAIN</div>
              </div>

              <button 
                onClick={() => setView('HOME')}
                className="font-serif italic text-xl border-b-2 border-black pb-1 hover:opacity-50 transition-all uppercase tracking-tighter"
              >
                Return to Archive
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Cart Drawer - Updated for theme */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-[2px] z-50 overflow-hidden"
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed top-0 right-0 w-full md:w-[500px] h-full bg-white z-[60] p-12 flex flex-col text-left border-l border-editorial-border"
            >
              <div className="flex items-center justify-between mb-16">
                <div>
                  <h2 className="font-serif text-4xl font-bold italic">Your Bag</h2>
                  <p className="text-[10px] font-black uppercase tracking-[0.3em] opacity-30 mt-2">Volume 01 / Selected</p>
                </div>
                <button 
                  onClick={() => setIsCartOpen(false)}
                  className="p-3 hover:bg-black/5 rounded-full transition-colors"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar">
                {items.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center opacity-40">
                    <ShoppingBag size={48} strokeWidth={1} className="mb-6" />
                    <p className="font-serif italic text-xl">Archive is Currently Empty.</p>
                  </div>
                ) : (
                  <div className="space-y-12">
                    {items.map((item) => (
                      <div key={`${item.id}-${item.size}`} className="flex gap-8 group">
                        <div className="w-24 h-32 bg-gray-50 border border-editorial-border p-1 shrink-0">
                          <img src={item.image} className="w-full h-full object-cover grayscale" alt={item.name} />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start mb-4">
                            <h3 className="font-serif italic text-2xl group-hover:underline decoration-1 underline-offset-4 transition-all">{item.name}</h3>
                            <button 
                              onClick={() => removeItem(item.id, item.size)}
                              className="text-black/20 hover:text-black transition-colors"
                            >
                              <X size={18} />
                            </button>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-6 font-medium text-sm">
                              <button onClick={() => updateQuantity(item.id, item.size, item.quantity - 1)} className="hover:opacity-50 transition-opacity">-</button>
                              <span className="w-4 text-center">{item.quantity}</span>
                              <button onClick={() => updateQuantity(item.id, item.size, item.quantity + 1)} className="hover:opacity-50 transition-opacity">+</button>
                            </div>
                            <span className="font-serif italic text-xl opacity-60">฿{(item.price * item.quantity).toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="pt-12 border-t border-editorial-border mt-auto">
                <div className="flex justify-between items-end mb-10">
                  <p className="text-[10px] font-black tracking-[0.4em] uppercase opacity-30 italic">Total Value</p>
                  <p className="font-serif italic text-5xl">฿{getTotal().toLocaleString()}</p>
                </div>
                <button 
                  disabled={items.length === 0}
                  onClick={() => {
                    setIsCartOpen(false);
                    setView('CHECKOUT');
                  }}
                  className="w-full bg-black text-white py-6 font-serif italic text-2xl hover:bg-[#222] transition-colors disabled:opacity-30 flex items-center justify-center gap-4"
                >
                  Checkout <ChevronRight size={20} />
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <footer className="border-t border-editorial-border py-12 px-8 bg-white mt-32">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center text-[10px] font-bold uppercase tracking-[0.4em] opacity-40 gap-8">
          <div className="italic">© 2024 BRAIN® APPAREL ARCHIVE</div>
          <div className="flex gap-12">
            <a href="#" className="hover:opacity-100 transition-opacity">Archive</a>
            <a href="#" className="hover:opacity-100 transition-opacity">Principles</a>
            <a href="#" className="hover:opacity-100 transition-opacity">Privacy</a>
          </div>
          <div>EST. 10110 / BANGKOK</div>
        </div>
      </footer>
    </div>
  );
}
