export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  category: string;
}

export interface CartItem extends Product {
  quantity: number;
  size: string;
}

export interface Address {
  firstName: string;
  lastName: string;
  street: string;
  subDistrict: string;
  district: string;
  province: string;
  country: string;
  postalCode: string;
  phone: string;
}

export interface OrderDetails {
  items: CartItem[];
  address: Address;
  total: number;
}
