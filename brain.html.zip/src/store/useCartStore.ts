import { create } from "zustand";
import { CartItem, Product } from "../types";

interface CartStore {
  items: CartItem[];
  addItem: (product: Product, size: string) => void;
  removeItem: (productId: string, size: string) => void;
  updateQuantity: (productId: string, size: string, quantity: number) => void;
  clearCart: () => void;
  getTotal: () => number;
}

export const useCartStore = create<CartStore>((set, get) => ({
  items: [],
  addItem: (product, size) => {
    const existingItem = get().items.find(
      (item) => item.id === product.id && item.size === size
    );

    if (existingItem) {
      set({
        items: get().items.map((item) =>
          item.id === product.id && item.size === size
            ? { ...item, quantity: item.quantity + 1 }
            : item
        ),
      });
    } else {
      set({ items: [...get().items, { ...product, quantity: 1, size }] });
    }
  },
  removeItem: (productId, size) => {
    set({
      items: get().items.filter(
        (item) => !(item.id === productId && item.size === size)
      ),
    });
  },
  updateQuantity: (productId, size, quantity) => {
    if (quantity <= 0) {
      get().removeItem(productId, size);
      return;
    }
    set({
      items: get().items.map((item) =>
        item.id === productId && item.size === size
          ? { ...item, quantity }
          : item
      ),
    });
  },
  clearCart: () => set({ items: [] }),
  getTotal: () => {
    return get().items.reduce((total, item) => total + item.price * item.quantity, 0);
  },
}));
