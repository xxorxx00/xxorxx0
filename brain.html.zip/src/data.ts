import { Product } from "./types";

export const PRODUCTS: Product[] = [
  {
    id: "brn-001",
    name: "BRAIN CORE TEE",
    price: 890,
    description: "Essential heavy cotton t-shirt with signature BRAIN logo.",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=1000&auto=format&fit=crop",
    category: "T-Shirts"
  },
  {
    id: "brn-002",
    name: "CEREBRAL OVERSIZE",
    price: 1200,
    description: "Oversized fit with high-density puff print.",
    image: "https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?q=80&w=1000&auto=format&fit=crop",
    category: "T-Shirts"
  },
  {
    id: "brn-003",
    name: "NEURAL NETWORK HOODIE",
    price: 1850,
    description: "Premium fleece hoodie for the thinking mind.",
    image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=1000&auto=format&fit=crop",
    category: "Hoodies"
  },
  {
    id: "brn-004",
    name: "MINDSET CAP",
    price: 590,
    description: "Classic 6-panel cap with minimalist embroidery.",
    image: "https://images.unsplash.com/photo-1588850561407-ed78c282e89b?q=80&w=1000&auto=format&fit=crop",
    category: "Accessories"
  }
];
